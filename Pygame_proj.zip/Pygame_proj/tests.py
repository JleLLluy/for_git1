t = 343
def tt():
    global t
    t = 1
tt()
print(t)